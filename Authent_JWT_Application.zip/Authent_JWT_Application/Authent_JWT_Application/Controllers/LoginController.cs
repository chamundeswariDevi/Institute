﻿using Authent_JWT_Application.Contracts;
using Authent_JWT_Application.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Authent_JWT_Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        static string securityKey = "";
        AuthentIF aif = null;
        public LoginController(AuthentIF auif)
        {
            this.aif = auif;
        }
        public static string? SecurityKey { get; internal set; }

       /*
        [Route("index")]
        public IActionResult Index()
        {
            return BadRequest();
        }
        */
        [HttpGet]
        [Route("LoginAuthent")]
        public IActionResult validateLogin([FromQuery] User user)
        {
            if (user.Username != null && user.Password != null)
            {
                if (user.Username.Equals("haritha") && user.Password.Equals("hari@15"))
                {
                    var token = aif.LoginAuthentication(user.Username, user.Password);
                    if (token == null)
                        return Unauthorized();
                    return Ok(token);
                }
                else
                {
                    return BadRequest();
                }

            }
            else
            {
                return BadRequest();
            }
        }

    }
}
