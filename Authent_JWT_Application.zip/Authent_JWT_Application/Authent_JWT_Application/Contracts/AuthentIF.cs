﻿namespace Authent_JWT_Application.Contracts
{
    public interface AuthentIF
    {
       public string LoginAuthentication(string username, string password);
    }
}
