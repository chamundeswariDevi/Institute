﻿namespace Authent_JWT_Application.Models
{
    public class User
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
