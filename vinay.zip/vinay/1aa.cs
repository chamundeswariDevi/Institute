using System;  
using System.IO;  
using System.Collections.Generic;
using System.Runtime.Serialization;  
using System.Runtime.Serialization.Formatters.Binary;  
public class SerializeEx2{  

    public void SerializeNow() {  

	//File to write serialized content  	
	//Open to create if not existing
        Stream str = File.Open("actinfo.dat",FileMode.Create);  
	
	//Code to serialize
       Employee1=new Employee1();
	
        BinaryFormatter b = new BinaryFormatter();  
        b.Serialize(str, a);  

	Console.WriteLine("Successfully Serialized");
        str.Close();  
    }  
    public void DeSerializeNow() {  
        Employee1=null;

	//Reading the content from same file  
        Stream str = File.Open("actinfo.dat",FileMode.Open);
	
	//Deserialize  
        BinaryFormatter b = new BinaryFormatter();  
        ac = (Employee1)b.Deserialize(str); 

	Console.WriteLine("no:{0},balance{1}",ac.AccountNo,ac.Balance);

        str.Close();  
    }  
    public static void Main(string[] s) {  
        SerializeEx2 sa = new SerializeEx2();  
        sa.SerializeNow();  
        sa.DeSerializeNow();  
    }  
}  
