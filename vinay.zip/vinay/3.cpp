using namespace System;
using namespace System::Collections::Generic;
ref class students
{
public :int  code;
	String^ title;
	int maxmarks;
	int obmarks;	
	students(int s,String^ t, int mm, int ms) {
		code = s;
		title = t;
		maxmarks = mm;
		obmarks= ms;
	}
};
 int main(){
	
	Dictionary<String^, Dictionary<String^, students^>^>^l1 = gcnew Dictionary<String^, Dictionary<String^, students^>^>();
	
	Dictionary<String^, students^>^ l2 = gcnew Dictionary<String^, students^>();
	students^ Vinay = gcnew students(11, "Computer Science", 100,75);
	students^ Vijay= gcnew students(12, "Social", 100, 65);
	students^ Vikram= gcnew students(13, "English", 100, 55);
	l2->Add("111	",Vinay);
	l2->Add("222", Vijay);
	l2->Add("333", Vikram);
	l1->Add("students", l2);	
	for each (KeyValuePair<String^, Dictionary<String^, students^>^> kvpb in l1) 
	{
	Console::WriteLine("students: {0}", kvpb.Key);
	for each (KeyValuePair<String^, students^> kvpb2 in kvpb.Value) {
	Console::WriteLine("roll:{0} code: {1}  sub: {2} maxmarks: {3} obmarks : {4} ", kvpb2.Key, kvpb2.Value->code,
	kvpb2.Value->title, kvpb2.Value->maxmarks,kvpb2.Value->obmarks);
	}
	}	
}
