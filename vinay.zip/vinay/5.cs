﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace ConsoleApp1
{
    internal class datasett
    {
        public void conection()
        {
            NpgsqlConnection conn;
            string cs;
            cs = "host=localhost:5432;Database=postgres;username=postgres;password=9666252852";
            DataSet ds = null;
            NpgsqlCommand cmd = null;
            NpgsqlDataAdapter da1 = null, da2 = null;

            try
            {
                conn = new NpgsqlConnection(cs);
                conn.Open();

                Console.WriteLine("Conn Opened Successfully");
               
                ds = new DataSet();
                da1 = new NpgsqlDataAdapter("select * from emp", conn);

                da2 = new NpgsqlDataAdapter("select * from dept", conn);
                da2.Fill(ds, "depts");

                cmd = new NpgsqlCommand("select * from salgrade", conn);
                da1.SelectCommand = cmd;
                da1.Fill(ds, "sg");

                Console.WriteLine("Data Set created with tables Successfully");
                foreach (DataTable dt in ds.Tables)
                {

                    Console.WriteLine("Table Name : " + dt.TableName +);

                    foreach (DataColumn dc in dt.Columns)
                    {
                        Console.WriteLine(dc.ColumnName);
                    }
                    foreach (DataRow dr in dt.Rows)
                    {
                        Console.WriteLine(dr[0] + "-" + dr[1]);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
public class mn
{
    public static void Main(string[] args)
    {
        datasett d = new datasett ();
        d.conection();
    }
}
