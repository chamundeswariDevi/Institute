using System;
using System.Collections.Generic;

class Employee1
{
public int no;
public string name;
public string job;
public int salary;
public int eno;
public	Employee1(int i,String n,string j,int sal,int d)
{
	no=i;
	name=n;
	job=j;
	salary=sal;
	eno=d;
}
}
class empmain
{
	public static void Main(string[] args)
	{
	List<Employee1>l1=new List<Employee1>();
	l1.Add (new Employee1(3434,"Mahesh","Test Engineer",25000,10));
	l1.Add (new Employee1(4545,"Naresh","Programmer",70000,20));
	l1.Add (new Employee1(4523,"Rajesh","Manager",50000,10));
	foreach(Employee1 e in l1)
	{
	string x=e.no.ToString();
        string y=e.name;
        string z=e.job;
        string x1=e.salary.ToString();
        string y1 =e.eno.ToString();
	//Console.WriteLine(x);
	//Console.WriteLine(y);
	Console.WriteLine("{0}",x +"\t"+ y +"\t"+ z + "\t" + x1 + "\t" + y1);
	
	}
	}
}