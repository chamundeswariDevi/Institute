using System;  
using System.IO;  
using System.Collections.Generic;
using System.Runtime.Serialization;  
using System.Runtime.Serialization.Formatters.Binary; 
[Serializable]
class Employee1
{
public int no;
public string name;
public string job;
public int salary;
public int eno;
public	Employee1(int i,String n,string j,int sal,int d)
{
	no=i;
	name=n;
	job=j;
	salary=sal;
	eno=d;
}
}
[Serializable]
class empmain
{
	public static void Main(string[] args)
	{
	List<Employee1>l1=new List<Employee1>();
	l1.Add (new Employee1(3434,"Mahesh","Test Engineer",25000,10));
	l1.Add (new Employee1(4545,"Naresh","Programmer",70000,20));
	l1.Add (new Employee1(4523,"Rajesh","Manager",50000,10));
  	Stream str = File.Open(fn,FileMode.Create);

	BinaryFormatter b = new BinaryFormatter();  
	 b.Serialize(str, l1);
	str.Close(); 

	Console.WriteLine("successfully Serialized");
	
	}
	}
}
 
